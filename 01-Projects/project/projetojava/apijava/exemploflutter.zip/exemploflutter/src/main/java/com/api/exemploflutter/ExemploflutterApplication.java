package com.api.exemploflutter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExemploflutterApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExemploflutterApplication.class, args);
	}

}
