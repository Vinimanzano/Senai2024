package com.api.exemploflutter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExemploflutterApplicationTests {

	@Test
	void contextLoads() {
	}

}
